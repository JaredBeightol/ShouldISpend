/*
    Author: Jared Beightol
    Date Started: 1/5/2021
    Last Update: 1/5/2021
    Purpose: A program that quantifies emotions and ideas to decide whether a purchase is a good idea or not.
*/
package com.example.shouldispend;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "demo";
    //Holds Max Scores for different questions
    int q1MaxScore = 100;
    int q2MaxScore = 50;
    int q3MaxScore = 10;
    int q4MaxScore = 80;
    int q5MaxScore = 100;
    int q6MaxScore = 50;
    //Holds the user Inputted scores for different questions
    int q1UserScore = 0;
    int q2UserScore = 0;
    int q3UserScore = 0;
    int q4UserScore = 0;
    int q5UserScore = 0;
    int q6UserScore = 0;
    //Declares Results textView
    TextView resultsTextView;
    //Holds the number of questions
    public static final int NUM_QUESTIONS = 6;
    //Creates AdView
    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Should I Spend");
        //Sets resultsTextView
        resultsTextView = findViewById(R.id.textViewResult);

        //Implements AdMob SDK
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        //When Button Is Clicked
        findViewById(R.id.buttonSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Gets the SeekBar progress that the user inputted for all questions
                getUserSeekBarInputs();
                //Calculate the rating of the User's desired purchase
                calculatePurchaseRating();
            }
        });

        //Adds an Ad
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // Create a banner ad. The ad size and ad unit ID must be set before calling loadAd.
        mAdView = new AdView(this);
        mAdView.setAdSize(AdSize.SMART_BANNER);
        mAdView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");

        // Create an ad request.
        AdRequest.Builder adRequestBuilder = new AdRequest.Builder();

        // Optionally populate the ad request builder.
        adRequestBuilder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);

        // Add the AdView to the view hierarchy.
        layout.addView(mAdView);

        // Start loading the ad.
        mAdView.loadAd(adRequestBuilder.build());

        setContentView(layout);
    }

    public void getUserSeekBarInputs(){
        //Gets all SeekBars for the questions
        SeekBar seekBar = findViewById(R.id.seekBar);
        SeekBar seekBar2 = findViewById(R.id.seekBar2);
        SeekBar seekBar3 = findViewById(R.id.seekBar3);
        SeekBar seekBar4 = findViewById(R.id.seekBar4);
        SeekBar seekBar5 = findViewById(R.id.seekBar5);
        SeekBar seekBar6 = findViewById(R.id.seekBar6);
        //Gets value from each SeekBar
        //Default Range for SeekBars is 0 - 100
        q1UserScore = (int)(seekBar.getProgress()*(q1MaxScore * .01));
        q2UserScore = (int)(seekBar2.getProgress()*(q2MaxScore * .01));
        q3UserScore = (int)(seekBar3.getProgress()*(q3MaxScore * .01));
        q4UserScore = (int)(seekBar4.getProgress()*(q4MaxScore * .01));
        q5UserScore = (int)(seekBar5.getProgress()*(q5MaxScore * .01));
        q6UserScore = (int)(seekBar6.getProgress()*(q6MaxScore * .01));
    }

    public void calculatePurchaseRating(){
        //Holds Max Score
        double maxScore = 0;
        double userScore = 0;
        //Gets all CheckBoxes
        CheckBox checkBox = findViewById(R.id.checkBox);
        CheckBox checkBox2 = findViewById(R.id.checkBox2);
        CheckBox checkBox3 = findViewById(R.id.checkBox3);
        CheckBox checkBox4 = findViewById(R.id.checkBox4);
        CheckBox checkBox5 = findViewById(R.id.checkBox5);
        CheckBox checkBox6 = findViewById(R.id.checkBox6);
        //Adds Scores if the box is checked
        if(checkBox.isChecked()){
            maxScore += q1MaxScore;
            userScore += q1UserScore;
        }
        if(checkBox2.isChecked()){
            maxScore += q2MaxScore;
            userScore += q2UserScore;
        }
        if(checkBox3.isChecked()){
            maxScore += q3MaxScore;
            userScore += q3UserScore;
        }
        if(checkBox4.isChecked()){
            maxScore += q4MaxScore;
            userScore += q4UserScore;
        }
        if(checkBox5.isChecked()){
            maxScore += q5MaxScore;
            userScore += q5UserScore;
        }
        if(checkBox6.isChecked()){
            maxScore += q6MaxScore;
            userScore += q6UserScore;
        }

        double rating = ((userScore/maxScore)*100);
        resultsTextView.setText("Rating: " + String.valueOf((int)rating) + " /100");
    }
}